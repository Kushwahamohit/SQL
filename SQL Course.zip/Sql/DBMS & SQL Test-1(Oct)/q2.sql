department 
dname  dnumber  mgr_ssn  mgr_start_date

dept_locations 
dnumber dlocation

 employee 
 fname lmane minit ssn bdate address sex salary super_ssn dno
 
 project
 pname pnumber plocation dnum
 
 works_on
 essn pno hours
 
 Q1.
Retrieve the Ssn ,name  and address of all employees who work for the ‘Administration’ department.  (2M  ) 
--- empoyee table 
select b.ssn,b.fname,b.lname,b.address
from employee as b
join department as a 
on a.mgr_ssn=b.super_ssn

Ouput:
                                                                                                          
 

Q2. 
For every project located in ‘Houston’, list the project number, the controlling department number, and the department manager’s last name, address, and birth date.                                                                                (3M)

Output:
 


Q3. Make a list of all project numbers and their locations  for projects that involve an employee whose last name is ‘Wong’, either as a worker or as a manager of the department that controls the project.      (5M)
 









Q4. Retrieve all employees in department 5 whose salary is between $30,000 and $40,000.   (2M)
Output:

 


Contd…..

 


Q5. Retrieve a list of employees and the projects they are working on, ordered by department and, within each department, ordered alphabetically by last name, then first name.                                       (5M)
Output:(only first 6 rows are shown in the output)

 

Q6. Show the resulting salaries if every employee working on the ‘ProductX’ project is given a 10 percent   raise.                                                                                                                                                                 (3M)
Output:
select c.fname,c.lname,(c.salary)*1.10 as salary
from employee as c
inner join
	(select b.pname,b.pnumber,a.essn
	from project  as b
	inner join works_on as a 
	on a.pno=b.pnumber
	where b.pname='ProductX') as d
on c.ssn=d.essn
 






Q7.Find the names of all the enployees who have a dependent with same last name and same sex as the employee.                                                                                                                                                               (5M)

 


Q8. Make a list of project numbers for projects that involve an employee whose Fisrt name is ‘Franklin’ either as a worker or as a manager of the department that controls the project                                              (9M)
 


Q9. List the names of the employees with no dependents                                    (3M)

       







Q10. List the names of the mangers who have atleast one dependent                                  ( 3M)

           
