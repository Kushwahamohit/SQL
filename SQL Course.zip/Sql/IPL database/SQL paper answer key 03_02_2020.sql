
Q1:FIND OUT THE NAMES OF THE CITIES AND VENUES IN WHICH TEAM - "ROYAL CHALLENGERS BANGALORE" PLAYED THEIR MATCHES
--SAMPLE OUTPUT
city			 venue
Pune	Subrata Roy Sahara Stadium
Ranchi	JSCA International Stadium Complex

--QUERY
select city,venue from matches
where team1='Royal Challengers Bangalore' or team2='Royal Challengers Bangalore'
group by city,venue;

--ANSWER
city				 venue
Bangalore		M Chinnaswamy Stadium
Mumbai			Wankhede Stadium
Delhi			Feroz Shah Kotla
Hyderabad		Rajiv Gandhi International Stadium
Kolkata			Eden Gardens
Chandigarh		Punjab Cricket Association Stadium
Jaipur			Sawai Mansingh Stadium
Chennai			MA Chidambaram Stadium
Cape Town		Newlands
Port Elizabeth	St Georges Park
Durban			Kingsmead
Johannesburg	New Wanderers Stadium
Centurion		SuperSport Park
Mumbai			Brabourne Stadium
Nagpur			Vidarbha Cricket Association Stadium
Mumbai			Dr DY Patil Sports Academy
Kochi			Nehru Stadium
Dharamsala		Himachal Pradesh Cricket Association Stadium
Pune			Subrata Roy Sahara Stadium
Ranchi			JSCA International Stadium Complex
Sharjah			Sharjah Cricket Stadium
Dubai 			International Cricket Stadium
Abu Dhabi		Sheikh Zayed Stadium
Ahmedabad		Sardar Patel Stadium
Pune			Maharashtra Cricket Association Stadium
Rajkot			Saurashtra Cricket Association Stadium
Chandigarh		Punjab Cricket Association IS Bindra Stadium
Raipur			Shaheed Veer Narayan Singh International Stadium


----------------------------------------------------------------------------------------------------------------------------------------------
--Most runs with batting average( total innings he played/ total runs he scored) 

Q2: LIST OUT BELOW DETAILS OF A BATSMAN WHO HAS MOST RUNS IN IPL.

--SAMPLE OUTPUT
batsman		total_innings		total_runs	 batting_average
DA Warner	128				3,850			30.07
--Note: Do not use LIMIT Function

--QUERY
SELECT batsman,
	COUNT(DISTINCT match_id) AS total_innings,
	SUM(batsman_runs) AS total_runs,
	ROUND(SUM(batsman_runs)/COUNT(DISTINCT match_id),2) AS batting_average
FROM deliveries
WHERE is_super_over=0
GROUP BY batsman
HAVING 
	total_runs =( 	SELECT max(total_runs) 
					FROM(
						SELECT batsman,
							SUM(batsman_runs) as total_runs 
						FROM deliveries
						WHERE is_super_over=0
						GROUP BY batsman
						)A
				)
;

--ANSWER
batsman		innings		total_runs	 batting_average
V Kohli		131			4,110			31.37
----------------------------------------------------------------------------------------------------------------------------------------------
--Most centuries
Q3: LIST OUT TOP 10 UNIQUE BATSMAN BASED ON NUMBER OF CENTURIES(batsman_runs >=100 IN A SINGLE MATCH) THEY MADE.
	LIST DOWN THEIR FIFTIES (batsman_runs >=50 BUT <100 IN A SINGLE MATCH) AS WELL. ORDERED IT BY DECREASING #100s, DECREASING #50s
	AND Batsman.

--SAMPLE OUTPUT
Batsman	 		50s		100s
AB de Villiers	21		3
DA Warner		32		2
V Sehwag		16		2
...
...

--QUERY
SELECT batsman, 
	SUM(CASE WHEN total_run BETWEEN 50 AND 99 THEN 1 ELSE 0 END) AS 50s,
	SUM(CASE WHEN total_run >=100 THEN 1 ELSE 0 END) AS 100s 
FROM(
	SELECT match_id, batsman,
		SUM(batsman_runs) AS total_run
	FROM deliveries 
	WHERE is_super_over=0
	GROUP BY match_id, batsman
	) A
GROUP BY batsman
ORDER BY 100s DESC,50s desc, batsman
limit 10;

--ANSWER
"
Batsman			50s	100s
CH Gayle		20	5
V Kohli			26	4
AB de Villiers	21	3
DA Warner		32	2
V Sehwag		16	2
SR Watson		14	2
M Vijay			13	2
AC Gilchrist	11	2
BB McCullum		11	2
RG Sharma		29	1
"
----------------------------------------------------------------------------------------------------------------------------------------------
Q4:FIND OUT NAME OF IPL WINNERS IN EACH SEASON?
--Only Final match is played on last day of season

"SAMPLE OUTPUT"
season		winner
2008	Pune Warriors
2009	Sunrisers Hyderabad
...
...

--QUERY
SELECT a.season,winner
FROM matches A
JOIN
	(SELECT season,MAX(date) AS max_date
	 FROM matches
	 GROUP BY season
	 ) B
ON A.season= B.season AND a.date=b.max_date;

--ANSWER
season		winner
2008	Rajasthan Royals
2009	Deccan Chargers
2010	Chennai Super Kings
2011	Chennai Super Kings
2012	Kolkata Knight Riders
2013	Mumbai Indians
2014	Kolkata Knight Riders
2015	Mumbai Indians
2016	Sunrisers Hyderabad

-------------------------------------------------------------------------------------------------------------------------------------------

Q5: NAME THE BOWLER WITH BEST BOWLING FIGURES.( MOST WICKET IN A MATCH WITH LEAST RUN)
 
--SAMPLE OUTPUT
season	 	city 			venue			bowler	 best_figures
2014	Bangalore	Sawai Mansingh Stadium	Bumrah		5-16 

--QUERY
SELECT 
	A.season,A.city,A.venue, C.bowler, 
	CONCAT(C.wickets,"-",C.total_runs) AS best_figures
FROM(
	SELECT
		season,id,city,venue 
	FROM matches  
	GROUP BY season,id,city,venue
    ) A
JOIN(
	SELECT B.* 
	FROM(
		SELECT 
			match_id,bowler, total_runs,wickets,
			RANK()over( ORDER BY wickets DESC,total_runs) AS ranking
		FROM(
			SELECT match_id,bowler, 
				SUM(total_runs) AS total_runs,
				SUM(CASE WHEN dismissal_kind IN('caught','bowled','lbw','stumped','caught and bowled') THEN 1 ELSE 0 END) AS wickets
			FROM deliveries
			WHERE is_super_over=0
			GROUP BY match_id,bowler
			) A
		) B
	WHERE ranking = 1
	)C
ON A.id=C.match_id;

--ANSWER
season	 	city 		venue				bowler	 best_figures
2008	Jaipur	Sawai Mansingh Stadium	Sohail Tanvir	6-15
----------------------------------------------------------------------------------------------------------------------------------------------
Q6- LIST OUT NAME, RUN AND TEAM NAME OF PLAYER ON SEASON WISE  WHO WEAR ORANGE CAP?

--SAMPLE OUTPUT
season	Batsman					team				total_runs	
2010	SR Tendulkar		Mumbai Indians				617
2011	CH Gayle		Royal Challengers Bangalore		608
...
...
...

--QUERY
SELECT season,Batsman,team,total_runs
FROM(
	SELECT A.season,B.batsman,B.batting_team AS team, 
		SUM(B.batsman_runs) AS total_runs, 
		RANK()over(PARTITION BY season ORDER BY SUM(B.batsman_runs) DESC) AS ranking
	FROM matches A
	JOIN deliveries B
	ON A.id=B.match_id
	GROUP BY A.season,B.batsman,batting_team
	) A
WHERE ranking=1
ORDER BY season;

--ANSWER
season	Batsman					team				total_runs	
2008	SE Marsh		Kings XI Punjab					616
2009	ML Hayden		Chennai Super Kings				572
2010	SR Tendulkar	Mumbai Indians					617
2011	CH Gayle		Royal Challengers Bangalore		608
2012	CH Gayle		Royal Challengers Bangalore		733
2013	MEK Hussey		Chennai Super Kings				733
2014	RV Uthappa		Kolkata Knight Riders			660
2015	DA Warner		Sunrisers Hyderabad				562
2016	V Kohli			Royal Challengers Bangalore		973
----------------------------------------------------------------------------------------------------------------------------------------------
Q7- Which team won by highest margin in each season ? (Note: 1 Wicket is comparable to 10 runs)  (10)
--SAMPLE OUTPUT

season		winner		winning_type
...
...
2011	Kings XI Punjab	111 Runs
2012	Mumbai Indians	10 Wickets
...
...

--QUERY
SELECT season,winner,winning_type
FROM(SELECT season,winner, 
		(CASE WHEN win_by_runs= 0 THEN CONCAT(win_by_wickets,' Wickets')
		 ELSE CONCAT(win_by_runs,' Runs') END) AS winning_type,
		 RANK()over(PARTITION BY season ORDER BY(win_by_runs+win_by_wickets*10) DESC) AS ranking
     FROM matches
	)A
WHERE ranking=1;

--ANSWER

season		winner						winning_type
2008	Kolkata Knight Riders			140 Runs
2009	Delhi Daredevils				10 Wickets
2010	Royal Challengers Bangalore		10 Wickets
2011	Kings XI Punjab					111 Runs
2012	Mumbai Indians					10 Wickets
2013	Royal Challengers Bangalore		130 Runs
2014	Chennai Super Kings				93 Runs
2015	Royal Challengers Bangalore		138 Runs
2016	Royal Challengers Bangalore		144 Runs

----------------------------------------------------------------------------------------------------------------------------------------------

Q8- CREATE A LIST OF TEAMS WITH THEIR WINNING RATIO (WINNING RATIO= TOTAL NO. OF MATCHES WON/TOTAL NO. OF MATCHES PLAYED)
	ORDER THEM BY DESCENDING WINNING RATIO. WINNING RATIO MUST BE UPTO 2 DECIMAL.
	
--SAMPLE OUTPUT
team_name		total_Matches	Won	 Lost	 win_ratio
Mumbai Indians		129			78	  59	  53.14%
Gujarat Lions		18			7	  10	  52.25%

--QUERY
SELECT 
	team_name, COUNT(*) AS total_Matches,
	SUM(CASE WHEN winning='Won' THEN 1 ELSE 0 END) AS Won,
	SUM(CASE WHEN losing='Lost' THEN 1 ELSE 0 END) AS Lost,
	CONCAT(ROUND(SUM(CASE WHEN winning='Won' THEN 1 ELSE 0 END)/COUNT(*)*100,2),"%") AS win_ratio
FROM(
	SELECT team1 AS team_name,
		(CASE WHEN result='normal' AND winner=team1 THEN 'Won' ELSE 'Unknown' END) AS winning,
		(CASE WHEN result='normal' AND winner <> team1 THEN 'Lost' ELSE 'Unknown' END) AS losing
	FROM matches
	UNION All
	SELECT team2 AS team_name, 
		(CASE WHEN result='normal' AND winner=team2 THEN 'Won' ELSE 'Unknown' END) AS winning,
		(CASE WHEN result='normal' AND winner <> team2 THEN 'Lost' ELSE 'Unknown' END) AS losing
	FROM matches
	)A
GROUP BY team_name
ORDER BY win_ratio DESC;

--ANSWER
team_name					total_Matches	Won	 Lost	 win_ratio
Chennai Super Kings				131			79	  51	  60.31%
Mumbai Indians					140			80	  60	  57.14%
Gujarat Lions					16			9	  7		  56.25%
Sunrisers Hyderabad				62			33	  28	  53.23%
Rajasthan Royals				118			61	  53	  51.69%
Kolkata Knight Riders			132			68	  62	  51.52%
Royal Challengers Bangalore		139			69	  66	  49.64%
Kings XI Punjab					134			61	  71	  45.52%
Kochi Tuskers Kerala			14			6	  8		  42.86%
Delhi Daredevils				133			56	  74	  42.11%
Deccan Chargers					75			29	  46	  38.67%
Rising Pune Supergiants			14			5	  9	      35.71%
Pune Warriors					46			12	  33	  26.09%



----------------------------------------------------------------------------------------------------------------------------------------------
Q9-FIND OUT SEASON,ID, BOWLER NAME, AGAINST WHICH TEAM AND THE VENUE WHERE BOWLERS TOOK HATTRICK IN A MATCH?

--SAMPLE OUTPUT
season  id	   bowler			 Opponent 							venue
2010	125	   P Kumar			Rajasthan Royals				M Chinnaswamy Stadium
2011	241	   A Mishra			Kings XI Punjab					Himachal Pradesh Cricket Association Stadium
2012	306	   A Chandila		Pune Warriors					Sawai Mansingh Stadium
...
...

--QUERY
SELECT A.season,A.id,B.bowler,(CASE WHEN bowling_team=team1 THEN team2 ELSE team1 END) AS Opponent,
A.venue 
FROM 
matches A
JOIN
(SELECT match_id, bowling_team,bowler 
FROM(
	SELECT A.*,
		Wickets+ LAG(wickets,1) over(PARTITION BY match_id,bowler ORDER BY over_number,ball)
		+ LAG(wickets,2) over(PARTITION BY match_id,bowler ORDER BY over_number,ball) AS hattrick_check
	FROM(
		SELECT match_id,bowling_team,bowler, over_number,ball,
			(CASE	WHEN dismissal_kind IN('caught','bowled','lbw','stumped','caught and bowled') 
					THEN 1 ELSE 0 END) AS wickets
		FROM deliveries
		) A
	)B 
WHERE hattrick_check=3)
B
ON A.id=B.match_id;

--ANSWER
season  id	   bowler			 Opponent 							venue
2008	32	   L Balaji			Kings XI Punjab					MA Chidambaram Stadium
2008	39	   A Mishra			Deccan Chargers					Feroz Shah Kotla
2008	44	   M Ntini			Kolkata Knight Riders			Eden Gardens
2009	80	   Yuvraj Singh		Royal Challengers Bangalore		Kingsmead
2009	88	   RG Sharma		Mumbai Indians					SuperSport Park
2009	105	   Yuvraj Singh		Deccan Chargers					'New' Wanderers Stadium
2010	125	   P Kumar			Rajasthan Royals				M Chinnaswamy Stadium
2011	241	   A Mishra			Kings XI Punjab					Himachal Pradesh Cricket Association Stadium
2012	306	   A Chandila		Pune Warriors					Sawai Mansingh Stadium
2013	341	   SP Narine		Kings XI Punjab					Punjab Cricket Association Stadium
2013	343	   A Mishra			Pune Warriors					Subrata Roy Sahara Stadium
2014	423	   PV Tambe			Kolkata Knight Riders			Sardar Patel Stadium
2014	428	   SR Watson		Sunrisers Hyderabad				Sardar Patel Stadium
2016	545	   AR Patel			Gujarat Lions					Saurashtra Cricket Association Stadium
