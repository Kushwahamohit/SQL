DATA DICTIONARY	
	1.   Table- matches: IPL match details across all seasons. It contains details related to the match such as location, contesting teams, umpires, results, etc.	
		
	Column	Description
	id	Unique id given for a match
	season	Year of that specific match
	city	Venue of the match
	date	Date the match was played
	team1	Team 1
	team2	Team 2
	toss_winner	Team who won the toss
	toss_decision	Decision taken by the toss winning team
	result	Normal/Draw/no-result/tie
	dl_applied	Is Duckworth-Lewis method applied during the match
	winner	Winning team
	win_by_runs	# runs the winning team won by (Incase they batted first)
	win_by_wickets	# wickets by which the winning team won by (Incase they chased)
	player_of_match	Man of the match
	venue	Stadium Name
	umpire1	Umpire 1
	umpire2	Umpire 2
	umpire3	Umpire 3
		
		
	2.    Table-deliveries: Ball by ball details for all matches for all seasons. It contains the ball-by- ball data of all the IPL matches including data of the batting team, batsman, bowler, non- striker, runs scored, etc.	
		
	Column	Description
	match_id	Unique id given for a match
	inning	Innings of the match (Values 3,4 comes in case match leads to super over)
	batting_team	Batting Team
	bowling_team	Bowling Team
	over_number	Over of the ball
	ball	Ball number
	batsman	Batsman facing the ball (Striker)
	non_striker	Batsman at the other end (Non Striker)
	bowler	Bowler
	is_super_over	Whether the over is super over or not
	wide_runs	# wide runs in that ball
	bye_runs	# Bye runs in that ball
	legbye_runs	# Leg bye runs in that ball
	noball_runs	# No ball runs in that ball
	penalty_runs	# Penalty runs in that ball
	batsman_runs	# Runs scored by batsman in that ball
	extra_runs	Total # Extra runs in that ball
	total_runs	Batsman_runs + Extra_runs
	player_dismissed	Name of the player who got out (NA in case of no wicket)
	dismissal_kind	Kind of Dismissal
	fielder	Fielder who helped for the dismissal (Incase of caught/runout/stumped)
	
	Database- IPL							
							
Q1:	1.HOW MANY MATCHES WERE PLAYED BETWEEN 'Kolkata Knight Riders' AND 'Rajasthan Royals'?						
Sample Output:		total_matches_played					
		11					
		select count(*) as total_matches_played
		from matches
		where (team1='Kolkata Knight Riders' and team2='Rajasthan Royals' ) or (team1='Rajasthan Royals' and team2='Kolkata Knight Riders')
							
Q2	FIND AVERAGE RUN SCORED BETWEEN 16-20 OVERS FOR EACH TEAM. ARRANGE IT IN DECREASING ORDER AND ROUND IT UPTO 2 DECIMAL						
Sample Output:		team	total match 	average_runs(16-20 over)			
		Sunrisers Hyderabad	56	39			
		Deccan Chargers	74	36			
SELECT batting_team as team, 
count(distinct match_id) as total_matches,
round(sum(total_runs)*1.0/count(distinct match_id),2) as average_runs
FROM DELIVERIES
where over_number between 16 and 20 and is_super_over = 0
group by batting_team
order by round(sum(total_runs)*1.0/count(distinct match_id),2) desc
							
							
Q3:	WHAT IS THE PERFORMACE OF "MUMBAI INDIANS" AGAINST "CHENNAI SUPER KINGS"?						
Sample Output:		Total_match_played	MI_won	CSK_won	Others		
		100	49	49	2		
		----table team 1 as csk team 2 as mi count_total wins loses
		-----
		select a.Total_match_played,a.MI_won,a.CSK_won,
		(a.Total_match_played-(a.MI_won+a.CSK_won)) as Others
		from
		(select count(*) as Total_match_played ,
		sum ( case when winner='Mumbai Indians' then 1 else 0 end) as MI_won,
		sum(case when winner='Chennai Super Kings' then 1 else 0 end ) as CSK_won
		from matches 
		where (team1='Mumbai Indians' and team2='Chennai Super Kings' ) or (team1= 'Chennai Super Kings'and team2= 'Mumbai Indians')
		 or result='no result'
		)a 
							
Q4	WHO IS THE EMERGING BATSMANS IN 2013 . (you can use window function)						
	(ELIGIBILITY TO BECOME EMERGING BATSMAN: 1ST TIME PLAYING IN IPL & PLAYED MINIMUM 5 MATCHES IN IPL-2013; SUPER_OVER IS NOT INCLUDED)						
Sample Output:		Batsman	run_scored				
		AB de Villiers	578				
		select batsman , count(*),sum(batsman_runs)
		from deliveries
		where is_super_over=0
		group by 1
		
		
							
	  
							
Q5	WHO IS 3RD HIGHEST WICKET TAKER IN IPL HISTORY. (DO NOT USE "LIMIT" FUNCTION BUT CAN CREATE INTERMEDIATE TABLES)						
	HINT: WICKET ONLY CREDIT TO BOWLER WHEN BATSMEN IS DISMISSED BY FOLLOWING WAYS:'CAUGHT','BOWLED','CAUGHT AND BOWLED','STUMPED','LBW','HIT WICKET'						
Sample Output:		 Bolwer name	wickets				
		SL Malinga	143				
----table bowler name- no of wickets 
----
    select a.bowler as"Bowler name",a.wickets
	from 
	(select bowler, count(*) as wickets, 
	dense_rank() over (order by count(*) desc) rank
	from deliveries 
	where dismissal_kind in('caught','bowled','caught and bowled','stumped','hit wicket','lbw')
	group by bowler)a
	where rank=3
	
							
Q6	 WHICH TWO PLAYERS HAVE HIGHEST PARTNERSHIP IN IPL. MENTION BATSMAN WITH TOTAL RUNS THEY SCORED TOGETHER						
Sample Output:	 	Batsman 1	Batsman2	total_partnership			
		S Dhawan	DA Warner	1711			
							
							
Q7:	FIND HOMEGROUND FOR EACH TEAM. (TEAM WHICH PLAYED MOST OF ITS MATCHES IN SPECIFIC VENUE IS TREATED AS THERE HOMEGROUND)						
Sample Output:		team	home_ground				
		Gujarat Lions	Saurashtra Cricket Association Stadium				
		Kings XI Punjab	Punjab Cricket Association Stadium				
		Kochi Tuskers Kerala	Nehru Stadium				
		--- first rank by partition for each team venue 
		---select rank 1 from each venue
		select * from 
		(select team1 as team ,venue, count(*) as no_of_match,from matchesgroup by 1,2)a
		inner join
        (select team2 as team ,venue, count(*) as no_of_match,from matchesgroup by 1,2)b 
		on a.team=b.team and a.venue=b.venue
		
		
							
							
							


							

