select batsman,count(*),sum(batsman_runs),avg(batsman_runs)
from deliveries
group by batsman
order by sum(batsman_runs) desc