---- SQL-Test ---- 
--- May_6 ---
--- Arv ---


select * from country_Data;
select * from country_married_perc;
select * from country_sex_ratio;


/*-----Part 1 -----*/

/*----Q1------*/

select INCOME_IND, count(distinct country) from  country_Data
group by 1;

select geography, count(distinct country) from  country_Data
group by 1;

/*----Q2------*/

select country,`30-34`
from country_married_perc
where sex = 'Women' 
order by `30-34` desc
limit 5;


/*----Q3----*/

select geography,country,a.sex,ratio
from
(
select geography,sex,max(`15-19`) as ratio
from
country_married_perc as pc
join country_Data as dt
on pc.country=dt.country
group by 1,2) as a 
join country_married_perc  pct
on a.ratio=pct.`15-19`


/*----Q4----*/

select i.subgroup,i.year,ratio_ind,ratio_pak,round((ratio_ind-ratio_pak),2) as Difference
from
(select country,subgroup,year,ratio as ratio_ind from country_sex_ratio
where country='India') as i
join
(select country,subgroup,year,ratio as ratio_pak from country_sex_ratio
where country='Pakistan') as p
on i.subgroup=p.subgroup
and i.year=p.year


/*---Part 2 ----*/


/*---Q1----*/

/*--- Dummy Logic-- Sex ratio closest to 100*/

select a.country from 
country_sex_ratio as a
join
(select min(abs(100-ratio)) as 100_ratio
from country_sex_ratio
where year=2005) as b
on abs(100-a.ratio)=b.100_ratio

/*---Q2----*/


 /*--- Dummy Logic-- avg of all the countries for different age group.No need to pick the column name by using code*/
 /*Marks will be given if attempted something*/
 
 
 /*-----Part 3-----*/
 
 /*----Q1-----*/
 
/*Cross Join*/
select country
from
(select a.country,a.sex as m_sex,a.`15-19` as m_gen, b.sex as f_sex,b.`15-19` as f_gen from country_married_perc as a
join country_married_perc as b
on a.country=b.country)  as c
where m_sex='Men' and f_sex='Female' and 
m_gen>f_gen

/*OR Self join */

select a.country from
(select country,`15-19` as m_gen from country_married_perc where sex='men') as a
join 
(select country,`15-19` as f_gen from country_married_perc where sex='Women') as b
on a.country=b.country
where m_gen>f_gen

/*Comparing with max age group */

select count(*)
from
(
select a.country from
(select country,`65+` as m_gen from country_married_perc where sex='men') as a
join 
(select country,`65+` as f_gen from country_married_perc where sex='Women') as b
on a.country=b.country
where m_gen>f_gen) as a

 /*----Q2-a-----*/
 
select subgroup,year,ratio_bucket,count(distinct country)
from
(select country,subgroup,year,
case when ratio<100 then '<100'
when ratio>=100 and ratio<110 then '100-110'
when ratio>=110 and ratio<120 then '110-120'
when ratio>=120 and ratio<130 then '120-130'
when ratio>=130 then '>130'
end as ratio_bucket
from country_sex_ratio) as b
group by 1,2,3

 /*----Q2-b-----*/

select 
case when ratio<100 then '<100'
when ratio>=100 and ratio<110 then '100-110'
when ratio>=110 and ratio<120 then '110-120'
when ratio>=120 and ratio<130 then '120-130'
when ratio>=130 then '>130'
end as ratio_bucket,count(*) as cnt
from
(select pc.country, avg(round(10000/ratio,2)) as ratio
from country_sex_ratio as pc
where subgroup='Total 60+ yr'
group by country) as a 
join country_Data as dt
on a.country=dt.country
group by
case when ratio<100 then '<100'
when ratio>=100 and ratio<110 then '100-110'
when ratio>=110 and ratio<120 then '110-120'
when ratio>=120 and ratio<130 then '120-130'
when ratio>=130 then '>130'
end

 /*----Q3-a-----*/

select sum((1.2*(`20-24`+`25-29`)-(`30-34`+`35-39`))) as age_30_35_of_population
from country_married_perc as pc
join country_Data as dt
on pc.country=dt.country
where geography like '%Asia%';

 /*----Q3-b-----*/

select sum((`20-24`+`25-29`)-(`30-34`+`35-39`)) as age_30_35_of_population
from country_married_perc as pc
join country_Data as dt
on pc.country=dt.country
where income_ind like '%Upper middle income%'

/* Part 4-----Assignment*/
/* ask if you have doubts in that */