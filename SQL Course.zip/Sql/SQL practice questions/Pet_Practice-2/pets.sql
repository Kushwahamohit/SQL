Questions		Required Columns in Output	Marks
1	Which Kind has the maximum number of male ? Mention the ratio in the output	Kind|Female to Male Ratio	10
    select kind,femaletomaleratio from
	(select kind,sum(case gender when 'male' then 1 else 0 end) as male_count,
	round((sum(case gender when 'female' then 1 else 0 end)*1.0/sum(case gender when 'male' then 1 else 0 end) ),2)as femaletomaleratio,
	rank() over (order by sum(case gender when 'male' then 1 else 0 end) desc) rank
	from pets
	group by 1)a
	where rank =1


2	Find the address (Streetaddress, City, State) of the person with highest number of pets	OWNERID|StreetAddress|City|StateFull|No. of Pets	15

select pets.ownerid,streetaddress,city,state, count(*) as no_of_pets
from pets
inner join owners
on pets.ownerid=owners.ownerid
group by pets.ownerid,streetaddress,city,state
having count(*)=
(
select max(no_of_pets)
from
(select ownerid, count(*) as no_of_pets
from pets
group by ownerid)a
)

3	Find the ProcedureType which has the maximum number of ProcedureSubCode, also list all of its ProcedureSubCodes	ProcedureType|ProcedureSubCode	15

create table max_procedure_list as
select proceduretype,count(*) as no_of_proceduresubcode
from proceduretype
group by proceduretype
having count(*)=
(select
max(no_of_proceduresubcode) from
(select proceduretype,count(*) as no_of_proceduresubcode
from proceduretype
group by proceduretype)a);
select distinct max_procedure_list.proceduretype,proceduresubcode
from max_procedure_list
inner join proceduretype
on proceduretype.proceduretype=max_procedure_list.proceduretype

4	How many times was each procedure done for dogs?	ProcedureType|No. of times Procedure done	10

select proceduretype,count(*) as no_of_procedure
from procedurehist a
inner join pets p
on a.petid=p.petid
where kind='Dog'
group by proceduretype

5	How often do different kinds of pets get VACCINATED (Avg days between VACCINATIONS)	KIND|date_diff	15
    

6	FIND Procedure subcode and total earnings from the 4th most opted proceduresubcode	ProcedureSubCode|Occurrence_count|Price per operation|Total Earning	15
		Total marks	80
----- calculated for every 4th rank in each proceduretype-proceduresubcode combination
select c.proceduretype,c.proceduresubcode,c.price*c.count as cost from
(select a.proceduretype,a.proceduresubcode,price,count(*) as count,
 dense_rank() over( order by count(*) desc ) rank
from procedurehist a
inner join proceduretype b
on a.proceduretype=b.proceduretype and a.proceduresubcode=b.proceduresubcode
group by 1,2,3
order by 1,2,3)c
where rank = 4








