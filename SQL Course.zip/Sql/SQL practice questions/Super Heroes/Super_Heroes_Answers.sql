-- What is the maximum power_level present accross the universe(Dataset).
SELECT MAX(Power_level) FROM heroes_info

-- What is the average height of Marvel Comics super heroes. (Don't consider the heroes with -99 height)
SELECT AVG(height) FROM heroes_info 
WHERE publisher = "Marvel comics"
AND height <> -99


-- How many good and bad super heroes present in each publication.
SELECT Publisher, Alinment, count(name) FROM heroes_info 
GROUP BY Publisher,Alinment 


-- How many female super heroes are present in each publication.
SELECT Publisher, count(name) FROM Heroes_info 
Where gender = "Female"
GROUP BY Publisher 


-- Which Race(s) have maximum number of super heroes. (Write the code assuming there are more than 1 race have maximum number of heroes.) 

CREATE TABLE Racecount as 
(SELECT Race, count(Name) c FROM Heroes_info 
GROUP BY RACE )

SELECT r1.* FROM Racecount r1 INNER JOIN
(SELECT MAX(c) K FROM racecount) r2
ON r1.c  = r2.K

-- Minimum number(Name also) of Marvel Comics male super heroes required to beat TEAM SAIYAN i.e. GOKU and VEGETA (Keep in mind that GOKU and VEGETA can fuse together to become VEGITO which is 5 times more powerfull than GOKU and VEGETA together)


DROP TABLE superhero.heroes_info_v2
CREATE TABLE superhero.heroes_info_v2 as
SELECT *, Row_Number() OVER( order by power_level desc) as rank_num
FROM heroes_info;

CREATE TABLE cumulative_sum as
SELECT a.NAME, a.power_level, SUM(b.power_level) as cummulative_power_level
FROM heroes_info_v2 as a 
LEFT JOIN
heroes_info_v2 as b
on a.rank_num >= b.rank_num
where a.publisher  = "Marvel Comics" and b.publisher  = "Marvel Comics"
group by a.NAME, a.power_level
order by a.power_level desc;


SELECT COUNT(Name) + 1 FROM Cum_sum 
WHERE cumulative_sum < (SELECT 5 *SUM(Power_LEVEL) FROM heroes_Info
WHERE Name IN ("GOKU","VEGETO"));

SELECT Name FROM cum_SUM LIMIT 8;


-- Can Marvel Comics Good super heroes beat DC Comics bad super heroes.(Fight gonna take place in such a universe where Height,Weight and Power will play 60%,30%,10% role in winning) 


SELECT  SUM(Height) + 0.3*SUM(Weight) + 0.1*SUM(Power_level) 
FROM 
heroes_info WHERE publisher = "Marvel Comics" AND Alinment  = "Good"
Group BY Publisher


SELECT  SUM(Height) + 0.3*SUM(Weight) + 0.1*SUM(Power_level) 
FROM 
heroes_info WHERE publisher = "DC Comics" AND Alinment  = "Bad"
Group BY Publisher

-- Name the most powerfull super heroes in each race across all publications. (Write the code assuming there are more than 1 super heores in each category)


CREATE TABLE heroes_info_pl as
SELECT PUBLISHER, RACE , MAX(Power_level) as max_power_level from heroes_info
GROUP BY Publisher, RAce ; 

SELECT a.Publisher, a.Race, a.Name
FROM heroes_info a 
INNER JOIN 
heroes_info_pl b
on a.race = b.race
and a.publisher = b.publisher
and a.power_level = b.max_power_level


-- Name the race(s) Not Present in each Publication

CREATE TABLE Cros AS 
( SELECT * FROM (SELECT DISTINCT(Publisher) FROM heroes_info) A JOIN 
(SELECT DISTINCT(Race) FROM Heroes_info) B)

CREATE TABLE AVAIl as (SELECT PUBLISHER, RACE FROM HEROES_INfo)

SELECT c.* FROM Cros c LEFT OUTER JOIN AVAIL a
ON c.publisher = a.publisher
AND c.Race = a.Race
WHERE v.race Is NULL and b.publisher is NULL


-- Name the Heroes having 2nd Highest Power Level

Create table nomax AS 
(SELECT h.* FROM heroes_info h 
LEFT JOIN 
(SELECT MAX(Power_level) K FROM heroes_info) a 
ON h.power_level = a.K
WHERE a.K is NULL)

(SELECT h.* FROM nomax h 
LEFT JOIN 
(SELECT MAX(Power_level) second_max FROM nomax) a 
ON h.power_level = a.second_max
WHERE a.second_max is NOT NULL)



