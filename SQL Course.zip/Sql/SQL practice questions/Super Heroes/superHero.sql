CREATE TABLE heroes_info (
  Name varchar(128) DEFAULT NULL,
  Gender varchar(128) DEFAULT NULL,
  Eye_Color varchar(128) DEFAULT NULL,
  Race varchar(128) DEFAULT NULL,
  Hair_Color varchar(128) DEFAULT NULL,
  Height int DEFAULT NULL,
  Publisher varchar(128) DEFAULT NULL,
  Alinment varchar(128) DEFAULT NULL,
  Weight int DEFAULT NULL,
  Power_Level int DEFAULT NULL
  
);
Note:
Take assumptions if required, don't forget to mention them  otherwise will be considered as mistake
Partial Marks will be awarded only if the logic is written and the code is commented. 
This is not a clean data set, remember to remove values which don't make sense only where they will create a difference.                            eg. height = -99 will effect the average height 

Round 1
What is the maximum power_level present accross the universe(Dataset).
select max(power_level) from heroes_info

What is the average height of Marvel Comics super heroes. (Don't consider the heroes with -99 height)'
--- we have the same name but different heights present in dataset so I consider each as distinct name as height is different
 
 select round(avg(height),2) from
 heroes_info
 where height!=(-99) and publisher='Marvel Comics'
 
How many good and bad super heroes present in each publication.

select publisher ,sum( case when alinment='good' then 1 else 0 end) as good_count,
	sum(case when alinment='bad' then 1 else 0 end) as bad_count
	from heroes_info
	where publisher !=''
	group by 1
	order by 1
	
How many female super heroes present in each publication.
select publisher ,
	sum(case when gender='Female' then 1 else 0 end) as female_count
	from heroes_info
	where publisher !=''
	group by 1
	order by female_count desc


Round 2
Which Race(s) have maximum number of super heroes. (Write the code assuming there are more than 1 race have maximum number of heroes.) 

 select race,count(*)as count
	 from heroes_info
	 where race!='-'
	 group by 1
	 having count(*)=
	(select max(count) from 
	(select race,count(*)as count
	 from heroes_info
	 where race!='-'
	 group by 1)a)
 
Minimum number(Name also) of Marvel Comics male super heroes required to beat  TEAM SAIYAN i.e. GOKU and VEGETA
(Keep in mind that GOKU and VEGETA can fuse together  to become VEGITO which is 5 times more powerfull than GOKU and VEGETA together)

Can Marvel Comics Good super heroes beat DC Comics bad super heroes. 
(Fight gonna take place in such a universe where Height,Weight and Power will play 60%,30%,10% role in winning ) 
--- seelct heroes of that criteria -union
--- first summing all the parameters individualy for both types of  heroes
---then assignning them values by multiplying
---sum(type a) compare with sum(type b)'DC Comics'
select a.publisher,(height_sum*60 + weight_sum*30 + power_sum*10) as combined_weightage_power,
		rank() over ( order by (height_sum*60 + weight_sum*30 + power_sum*10) desc) rank
		from 
		(select  publisher,sum(height) as height_sum,sum(weight) as weight_sum,sum(power_level)as power_sum
		from heroes_info
		where publisher in ('Marvel Comics','DC Comics') and height!=(-99) and weight!=(-99) 
		group by 1
		order by 1)a

Round 3
Name the most powerfull super heroes in each race across all publications. 
(Write the code assuming there are more than 1 super heores in each category)
----answer is across each publication 
select a.publisher,a.race,a.name
from 
(select publisher,race,name,sum(power_level) as total_power,
rank() over (partition by publisher,race order by sum(power_level) desc) rank
from heroes_info
where race!='-' and publisher!=''
group by 1,2,3)a
group by 1,2,3
where rank =1

Name the race(s) Not Present in each Publication
--select crosstab(distinct publisher,distinct race crossjoin)
--select datatab(from datset)
---left join crosstab,datatab
---find the publiction, race in crosstab for whose value is null in right datatab
select c.publisher,c.race
from
(select *  from 
(select distinct publisher from heroes_info where publisher !='')a
inner join (select distinct  race from heroes_info where race !='-')b 
on 1=1)c
left join
		(select distinct publisher, race
		from heroes_info)d
on c.publisher=d.publisher and c.race=d.race
where d.publisher is null and d.race is null
group by 1,2

Name the Heroes having 2nd Highest Power Level
select a.name
from (
select name,dense_rank() over (order by power_level desc)rank
from heroes_info
order by rank)a
where a.rank =2
