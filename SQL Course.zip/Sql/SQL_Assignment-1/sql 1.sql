pokemongo_basedata
pokemonId int,appearedHour int,appearedDayofweek  varchar(40),appearedcity varchar(40),continent varchar(40),weather varchar(40),
temperature numeric(20,3),population_density numeric(20,3),urban varchar(40),suburban varchar(40),
midurban varchar(40),rural varchar(40),gymDistanceKm varchar(40)

 pokemon_ability_data

PokemonID int,
Pokemon varchar(40),
Ability varchar(40),
Hidden_Ability varchar(40)
-------------------------------------
											
Part-1											
1) Which is most popular pokemon it terms of sighting?	

	select pokemon , count(appearedHour) as no_of_times_appeared
	from pokemongo_basedata b
	inner join pokemon_ability_data c
	on b.pokemonid=c.pokemonid
	group by 1
    having count(appearedHour)
	=
	(select max(a.no_of_times_appeared)
	from 
	(select pokemonId , count(appearedHour) as no_of_times_appeared
	from pokemongo_basedata
	group by 1)a )
									
2) What percent of pokemons appeared in urban, suburban, midurban and rural areas?	
--- considerin each occrance as different pokemon occurance
    
	select
	sum(case when urban='TRUE' then 1 else 0 end)*100.0/count(*)  as urban_percentage,
	suburban(case when suburban='TRUE' then 1 else 0 end)*100.0/count(*) as suburban_percentage	
	from pokemongo_basedata
	
3) Which city is the most popular inhabitant of pokemons in "Clear" weather?	

  	select appearedcity ,count(appearedHour)
	from pokemongo_basedata
    where weather='Clear'	
	group by 1
	order by count(appearedHour) desc
		
4) Pokemon are more likely to appear in which hour of the day for areas where population density varies between 200 to 700?		
---considering each appearance as distinct
    select appearedHour,count(*)
	from pokemongo_basedata
	where population_density between 200 and 700
		group by 1
		order by 1 desc
5) What is the most common hidden ability of Pokemons											
	select 	hidden_ability,count(*)
	from pokemon_ability_data
		group by 1
		order by count(*) desc
		
Part-2											
"1) Name the pokemon which has the highest probability of appearing in morning, afternoon, 
evening and night respectively? "											
(morning= 5 to 12 , afternoon=12 to 16, evening=16 to 19, night=19 to 5)				
----creat a tablewith pokemon and its apperance time
	
	select a.pokemonId,count(*)
	from 
	(select pokemonId,appearedHour,
	case 
	when appearedHour> 5 and appearedHour<12 then 'morning'
	when appearedHour>12 and appearedHour<16 then 'afternoon'
	when appearedHour>16 and appearedHour<20 then 'evening'
	else 'night'
	end as appearedtime
	from pokemongo_basedata)a
	where appearedtime='afternoon'
	group by 1
	order by count(*) desc
	
	
	 
	
	
2) What is the average population density of the area where "Pikachu" and "Bulbasur" appeared?				
---innner join to get name a,b
---select distinct pikachu,city,population_density		c
---select distinct bulbasaur,city,population_density d
---inner join a and b on city,population_density e
--- average of that population city 
create table data as
select *
from pokemon_ability_data a
inner join pokemongo_basedata b
on a.pokemonId=b.pokemonId

3) "Bulbasaur" has the highest probability to appear on which day of the week?											
											
Part-3											
1) For every city find the pokemons which did NOT appeared at all											
2) Which one is the most favourable weather for Pokemon to appear for each week day											


Part-1		
    3) Which city is the most popular inhabitant of pokemons in "Clear" weather?	
	    count of appearance for each city where  weather is clear
		selct max
		
		select appearedcity,count(*) as no_of_appearance_in_the_city
		from pokemongo_basedata
		where weather='Clear'
		group by appearedcity
		
	2) What percent of pokemons appeared in urban, suburban, midurban and rural areas?	
	----considering all pokemon_appearance unique
       select 
		round(sum(case when urban ='TRUE' then 1 else 0 end)*100.00/count(*) ,2)as urban_percentage,
		round(sum(case when suburban='TRUE' then 1 else 0 end)*100.00/count(*) ,2)as suburban_percentage
		from pokemongo_basedata
	
	1) Which is most popular pokemon it terms of sighting?	
       max no of sighting
	   match using having
	  
	  select pokemonId,pokemon,count(*) as countofappearance
	  from pokemongo_basedata b
	  inner join pokemon_ability_data c
	  b.pokemonId=c.pokemonId
	  group by pokemonId,pokemon
	  having count(*)=
	 ( select max(countofappearance) from 
	 ( select pokemonId,count(*) as countofappearance
	  from pokemongo_basedata
	  group by pokemonId) a)
											
											
	4) Pokemon are more likely to appear in which hour of the day for areas where population density varies between 200 to 700?	
		select appearedHour,count(*) as no_of_pokemons_appeared
		from pokemongo_basedata
		where population_density >200 and population_density<700
		group by appearedHour
		having count(*)=
		(select max(no_of_pokemons_appeared) from
		(select appearedHour,count(*) as no_of_pokemons_appeared
		from pokemongo_basedata
		where population_density >200 and population_density<700
		group by appearedHour) a)
	5) What is the most common hidden ability of Pokemons	
	 
		select Hidden_Ability,count(*) as count
		from pokemon_ability_data
		group by Hidden_Ability
		having count(*)=
	    ( select max(count) from
	    (select Hidden_Ability,count(*) as count
		from pokemon_ability_data
		group by Hidden_Ability)a)
	
												
	Part-2											
	"1) Name the pokemon which has the highest probability of appearing in morning, afternoon, 
evening and night respectively? "											
	(morning= 5 to 12 , afternoon=12 to 16, evening=16 to 19, night=19 to 5)	

		select b.pokemonid,pokemon,
		round(sum(case when appearedHour between 5 and 12 then 1 else 0 end)*1.0/count(*),2)as morning_probability
		from pokemongo_basedata b
		inner join pokemon_ability_data c
		on b.pokemonId=c.pokemonId
		group by b.pokemonId,pokemon
		having round(sum(case when appearedHour between 5 and 12 then 1 else 0 end)*1.0/count(*),2)=
		(select max(morning_probability) from
		(select pokemonid,
		round(sum(case when appearedHour between 5 and 12 then 1 else 0 end)*1.0/count(*),2)as morning_probability
		from pokemongo_basedata
		group by pokemonId)a)
		
	2) What is the average population density of the area where "Pikachu" and "Bulbasur" appeared?		
------- crete table where pikachu appeared 
------- create table where Bulbasaur appeared
-------inner join on appearedcity and population density
        create table pikachu_appeared as
			select *
			from pokemongo_basedata a
			inner join pokemon_ability_data b
			 on a.pokemonId=b.pokemonid
            where pokemon='Pikachu';
		create table Bulbasaur_appeared as
			select *
			from pokemongo_basedata a
			inner join pokemon_ability_data b
			 on a.pokemonId=b.pokemonid
            where pokemon='Bulbasaur';
		select round (avg(distinct a.population_density),2)
			from pikachu_appeared a
			inner join Bulbasaur_appeared b
			on a.appearedcity=b.appearedcity
			and a.population_density=b.population_density
			
	3) "Bulbasaur" has the highest probability to appear on which day of the week?		
        categories the count based on day
			
			select appearedDayofweek,count(*)
			from pokemongo_basedata a 
			inner join pokemon_ability_data b 
			on a.pokemonId=b.pokemonId
			where pokemon='Bulbasaur'
												
	Part-3											
	1) For every city find the pokemons which did NOT appeared at all		
	 --- crosstab (inner join of distinct values table resulted )- datatab-leftjoin -places where null
	 
	    create table crosstab as
		(select * 
		from ( select distinct pokemonId from pokemongo_basedata) a
		inner join(select distinct appearedcity from  pokemongo_basedata) b 
		on 1=1
		order by pokemonid,appearedcity)
		
	    create table datatab as
		select distinct pokemonid,appearedcity from pokemongo_basedata
		order by pokemonid,appearedcity
		
		select c.appearedcity,c.pokemonid
		from crosstab c
		left join datatab d 
		on c.pokemonId=d.pokemonId and c.appearedcity=d.appearedcity
		where d.appearedcity is null
		group by c.appearedcity,c.pokemonid
		
		 
	
	2) Which one is the most favourable weather for Pokemon to appear for each week day		
	----- each weekday-weather-wethercount-rank by partition based on weekday
	      
		  select appearedDayofweek,weather,rank from
			(select  appearedDayofweek,weather,count(*) as weather_count,
				rank() over (partition by appearedDayofweek order by count(*) desc) rank
			from pokemongo_basedata
			group by appearedDayofweek,weather
			order by appearedDayofweek ,weather) a
			)
			group by 1,2,3
			having rank=1



	
												
